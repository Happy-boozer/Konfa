import tarfile
def echo(*args):
    print(*args)
    #return args

def ls():
    namelist = tarfile.getnames()
    for file in namelist:
        print(file)